HORROR PLAYER QUIZ  (v1 Full-release)
======================================

เล่นยังไง / How to play
1. แตกไฟล์ zip ทั้งหมดก่อน (คลิกขวา > Extract All / แตกไฟล์)  Extract the whole zip first.
2. ดับเบิลคลิกไฟล์ index.html  Double-click index.html. It opens in your browser.

อย่าลบหรือย้ายไฟล์ออกจากโฟลเดอร์นี้ / Keep all files together in this folder:
  index.html, manifest.webmanifest, sw.js, icons/icon-512.png

หมายเหตุ / Notes
- เล่นได้แม้ไม่มีเน็ต แต่ฟอนต์จะเป็นฟอนต์ของเครื่อง และสถิติผู้เล่นจะเป็นตัวเลขสนุกๆ
  Works offline, but you get your device's fonts and the player statistics shows a fun estimate.
- ปุ่มติดตั้งแอปใช้ได้เฉพาะบนเว็บ ไม่ใช่ไฟล์ในเครื่อง
  The Install button only works on the website, not from a local file.
- เว็บเต็ม / Full website: https://horror-player-quizbypoy.nrbdiyunyaw.workers.dev/
